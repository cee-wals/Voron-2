Print 4 pieces. Insert standard heatsets. Use Qty 2 M3x8 SHCS or BHCS.
Wire openings for Keenovo standard wires for the bed heater, bed thermistor, ground wire.

![Image of grommet chamber side](./images/chamber_side.jpg)
![Image of grommet elec. side](./images/elec_bay_side.jpg)
